print("Luas Tanah pak Joni dan pak Sony")
print ("panjang = 12")
print ("Lebar = 10")
print ("maka rumusnya  (12x10)/0.5 = ? ")
a = 12
b = 10
c = 0.5*a*b
print(c)
print ("jadi pak Joni dan pak Soby masing - masing memiliki luas tanah {}".format (c))
